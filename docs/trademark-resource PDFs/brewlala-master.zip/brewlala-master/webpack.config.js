module.exports = {
  externals: {
    jquery: 'jQuery'
  },
};
