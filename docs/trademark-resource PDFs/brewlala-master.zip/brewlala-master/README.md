# Brewlala

## Install

1. `npm install`
2. `gulp`
3. Replace instances of `wp-brew.local` with desired url
4. Add to existing WordPress install (this assumes you have ACF pro installed already)
5. Set the homepage to a static page and assign it the `front` page template

**NOTE:** Uncomment lines 153-155 in `functions.php` to run the scrape on next page load (and then weekly after that)
